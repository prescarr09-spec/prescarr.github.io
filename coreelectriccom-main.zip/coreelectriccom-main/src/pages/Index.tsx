import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import About from "@/components/About";
import Reviews from "@/components/Reviews";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>Core Electric | Professional Electrician in Bakersfield, CA</title>
        <meta
          name="description"
          content="Core Electric - Your trusted electrician in Bakersfield, CA. 4.8 star rated with 75+ reviews. Residential & commercial electrical services. Call (661) 338-0885 for a free quote."
        />
        <meta name="keywords" content="electrician Bakersfield, electrical services, residential electrician, commercial electrician, panel upgrade, Core Electric" />
        <link rel="canonical" href="https://coreelectric.com" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Electrician",
            "name": "Core Electric",
            "image": "",
            "url": "https://coreelectric.com",
            "telephone": "(661) 338-0885",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "9530 Hageman Rd b269",
              "addressLocality": "Bakersfield",
              "addressRegion": "CA",
              "postalCode": "93312",
              "addressCountry": "US"
            },
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.8",
              "reviewCount": "75"
            },
            "openingHoursSpecification": {
              "@type": "OpeningHoursSpecification",
              "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
              "opens": "09:00",
              "closes": "17:00"
            }
          })}
        </script>
      </Helmet>

      <div className="min-h-screen">
        <Header />
        <main>
          <Hero />
          <Services />
          <About />
          <Reviews />
          <Contact />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;

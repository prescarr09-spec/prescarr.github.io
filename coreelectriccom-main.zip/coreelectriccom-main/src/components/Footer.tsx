import { Zap, Phone, MapPin, Clock } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary text-secondary-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand Column */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="font-heading text-2xl font-bold">Core Electric</span>
            </div>
            <p className="text-secondary-foreground/70 mb-6 max-w-md">
              Your trusted electrician in Bakersfield, CA. Providing professional electrical services with exceptional quality and customer satisfaction.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="tel:6613380885"
                className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors font-semibold"
              >
                <Phone className="w-5 h-5" />
                (661) 338-0885
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <a href="#home" className="text-secondary-foreground/70 hover:text-primary transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#services" className="text-secondary-foreground/70 hover:text-primary transition-colors">
                  Services
                </a>
              </li>
              <li>
                <a href="#about" className="text-secondary-foreground/70 hover:text-primary transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#reviews" className="text-secondary-foreground/70 hover:text-primary transition-colors">
                  Reviews
                </a>
              </li>
              <li>
                <a href="#contact" className="text-secondary-foreground/70 hover:text-primary transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4">Contact Info</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-secondary-foreground/70">
                <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span>
                  9530 Hageman Rd b269<br />
                  Bakersfield, CA 93312
                </span>
              </li>
              <li className="flex items-start gap-3 text-secondary-foreground/70">
                <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span>
                  Mon - Fri: 9 AM - 5 PM<br />
                  Sat - Sun: Closed
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-secondary-foreground/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-secondary-foreground/50 text-sm">
            © {currentYear} Core Electric. All rights reserved.
          </p>
          <p className="text-secondary-foreground/50 text-sm">
            Licensed & Insured Electrician • Bakersfield, CA
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

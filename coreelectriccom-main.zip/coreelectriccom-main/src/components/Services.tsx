import { Zap, Home, Building2, Plug, Shield, Sun, Wrench, Lightbulb } from "lucide-react";

const services = [
  {
    icon: Home,
    title: "Residential Electrical",
    description: "Complete home electrical services including wiring, repairs, and upgrades for safety and efficiency.",
  },
  {
    icon: Building2,
    title: "Commercial Electrical",
    description: "Professional electrical solutions for businesses, offices, and commercial properties.",
  },
  {
    icon: Plug,
    title: "Panel Upgrades",
    description: "Modernize your electrical panel to handle increased power demands and improve safety.",
  },
  {
    icon: Shield,
    title: "Safety Inspections",
    description: "Comprehensive electrical inspections to identify hazards and ensure code compliance.",
  },
  {
    icon: Sun,
    title: "Solar Ready",
    description: "Prepare your home or business for solar panel installation with proper electrical infrastructure.",
  },
  {
    icon: Lightbulb,
    title: "Lighting Installation",
    description: "Expert installation of indoor and outdoor lighting systems for any space.",
  },
  {
    icon: Wrench,
    title: "Repairs & Maintenance",
    description: "Quick and reliable electrical repairs and routine maintenance services.",
  },
  {
    icon: Zap,
    title: "Emergency Services",
    description: "24/7 emergency electrical services when you need immediate assistance.",
  },
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-primary font-semibold uppercase tracking-wider mb-4">
            What We Offer
          </span>
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-6">
            Our Electrical Services
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From residential repairs to commercial installations, we provide comprehensive electrical solutions tailored to your needs.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="group bg-card rounded-xl p-6 shadow-card hover:shadow-elevated transition-all duration-300 hover:-translate-y-1 border border-border"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary group-hover:electric-glow transition-all duration-300">
                <service.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
              </div>
              <h3 className="font-heading text-xl font-semibold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;

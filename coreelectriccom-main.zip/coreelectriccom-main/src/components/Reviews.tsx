import { Star, Quote } from "lucide-react";

const reviews = [
  {
    name: "Roxanne Esparza",
    date: "6 days ago",
    rating: 5,
    text: "Contractor Core Electric was chosen by my Home Warranty. Ivan was assigned to my claim and he was very knowledgeable and helpful. He fixed the issue quickly. He provided me with advice for my home and explained safety tips for my electrical system.",
  },
  {
    name: "Buddy Iahn",
    date: "2 years ago",
    rating: 5,
    text: "I always contact Ivan whenever I need electrical work done at my house. He's knowledgeable, professional, and does great work. I recently had a new electrical box installed that's solar ready, and he was very well-versed in the process.",
  },
  {
    name: "TJ Brown",
    date: "10 months ago",
    rating: 5,
    text: "Bryan was very professional and informative. He was very fast and cleaned up after himself as well. He even took the time to answer questions that I had. I would definitely recommend Core Electric.",
  },
];

const highlights = [
  "He was quick, efficient, personable and gave us a great price!!",
  "I really appreciate the work and the communication.",
  "His prices are also the best in town!",
];

const Reviews = () => {
  return (
    <section id="reviews" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-primary font-semibold uppercase tracking-wider mb-4">
            Testimonials
          </span>
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-6">
            What Our Customers Say
          </h2>

          {/* Rating Summary */}
          <div className="inline-flex items-center gap-4 bg-card rounded-full px-6 py-3 shadow-card border border-border">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 text-accent fill-accent" />
              ))}
            </div>
            <span className="font-heading text-2xl font-bold text-foreground">4.8</span>
            <span className="text-muted-foreground">from 75 reviews</span>
          </div>
        </div>

        {/* Review Highlights */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {highlights.map((highlight, index) => (
            <div
              key={index}
              className="bg-primary/5 border border-primary/20 rounded-xl p-6 text-center"
            >
              <Quote className="w-8 h-8 text-primary mx-auto mb-4 opacity-50" />
              <p className="text-foreground font-medium italic">"{highlight}"</p>
            </div>
          ))}
        </div>

        {/* Review Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <div
              key={review.name}
              className="bg-card rounded-xl p-6 shadow-card border border-border hover:shadow-elevated transition-all duration-300"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="font-heading text-xl font-bold text-primary">
                      {review.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{review.name}</h4>
                    <p className="text-sm text-muted-foreground">{review.date}</p>
                  </div>
                </div>
              </div>

              {/* Stars */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-accent fill-accent" />
                ))}
              </div>

              {/* Review Text */}
              <p className="text-muted-foreground leading-relaxed">{review.text}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <a
            href="https://www.google.com/maps"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-primary font-semibold hover:underline"
          >
            Read All 75 Reviews on Google
            <Star className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Reviews;

import { CheckCircle, Award, Users, Clock } from "lucide-react";
import { Button } from "./ui/button";

const stats = [
  { icon: Award, value: "75+", label: "5-Star Reviews" },
  { icon: Users, value: "500+", label: "Happy Customers" },
  { icon: Clock, value: "10+", label: "Years Experience" },
];

const features = [
  "Licensed & Insured Electricians",
  "Upfront Pricing - No Hidden Fees",
  "Satisfaction Guaranteed",
  "Fast Response Times",
  "Residential & Commercial Expertise",
  "Solar Ready Installations",
];

const About = () => {
  return (
    <section id="about" className="py-24 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div>
            <span className="inline-block text-primary font-semibold uppercase tracking-wider mb-4">
              About Us
            </span>
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-6">
              Bakersfield's Trusted Electrical Experts
            </h2>
            <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
              At Core Electric, we take pride in providing top-quality electrical services to Bakersfield and the surrounding areas. Our team of skilled electricians is dedicated to delivering safe, reliable, and efficient electrical solutions for your home or business.
            </p>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              With years of experience and a commitment to excellence, we've earned a reputation for outstanding workmanship and exceptional customer service. Our clients trust us because we're knowledgeable, professional, and always go the extra mile.
            </p>

            {/* Features List */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {features.map((feature) => (
                <div key={feature} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-foreground font-medium">{feature}</span>
                </div>
              ))}
            </div>

            <Button size="lg">Learn More About Us</Button>
          </div>

          {/* Right Column - Stats & Image */}
          <div className="relative">
            {/* Stats Cards */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              {stats.map((stat) => (
                <div
                  key={stat.label}
                  className="bg-card rounded-xl p-6 text-center shadow-card border border-border"
                >
                  <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <div className="font-heading text-3xl font-bold text-foreground mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Feature Card */}
            <div className="bg-secondary text-secondary-foreground rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full blur-2xl"></div>
              <h3 className="font-heading text-2xl font-bold mb-4 relative z-10">
                Why Choose Core Electric?
              </h3>
              <ul className="space-y-3 relative z-10">
                <li className="flex items-start gap-3">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2"></span>
                  <span>Quick, efficient, and personable service</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2"></span>
                  <span>Best prices in Bakersfield</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2"></span>
                  <span>Clear communication throughout</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2"></span>
                  <span>Expert advice and safety tips</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
